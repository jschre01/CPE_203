public interface Entity_Animation extends Entity_Action{
    int getAnimationPeriod();
}
